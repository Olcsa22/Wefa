package ch.poole.poparser;

public class PoEntry {
	String msgCtxt;
	String msgId;
	String msgIdPlural;
	String msgStr;
}
