# No Contributor Code of Conduct

Please be respectful of and polite to everybody involved in this project, or please get lost.

We do not expect any alignment of both users and contributors with any specific political agenda, particularly not with that of the authors of the [Contributor Covenant](http://contributor-covenant.org).
