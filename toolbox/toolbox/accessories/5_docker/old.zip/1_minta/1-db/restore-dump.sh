# szedd le a kommentet (veletlen meghivas elkerulese miatt van igy)
# docker exec -i postgres1 createdb -U "postgres" "dbname";

# 10 sec sleep
sleep 10;

# ez plain (SQL statementek) postgres dump-hoz van (de van bin�ris lehetoseg is, ott m�s util/command kell)
# szedd le a kommentet (veletlen meghivas elkerulese miatt van igy)
# docker exec -i postgres1 psql -U "postgres" -d "dbname" < "db.dump";