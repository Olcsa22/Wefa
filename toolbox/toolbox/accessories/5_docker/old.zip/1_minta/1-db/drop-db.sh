# szedd le a kommentet (veletlen meghivas elkereulese miatt van igy)
# docker exec -i postgres1 dropdb -U "postgres" "dbname"