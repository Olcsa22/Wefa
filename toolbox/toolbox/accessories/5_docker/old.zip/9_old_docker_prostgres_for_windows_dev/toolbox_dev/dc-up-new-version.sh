docker compose --compatibility up --detach
read -p "Press enter to continue" nothing