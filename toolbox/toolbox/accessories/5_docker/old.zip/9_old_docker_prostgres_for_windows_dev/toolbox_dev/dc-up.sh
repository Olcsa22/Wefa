docker-compose --compatibility up --detach --remove-orphans
read -p "Press enter to continue" nothing