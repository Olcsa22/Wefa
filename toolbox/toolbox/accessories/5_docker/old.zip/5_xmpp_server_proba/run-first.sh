docker run --name openfire1 -d --restart=always \
  --publish 9090:9090 --publish 5222:5222 --publish 7070:7070 \
  --volume xmpp-proba-1:/var/lib/openfire \
  sameersbn/openfire:3.10.3-19
  
  read -p "Press enter to continue"