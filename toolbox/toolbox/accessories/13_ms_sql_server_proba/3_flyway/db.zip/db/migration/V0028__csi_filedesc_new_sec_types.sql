INSERT INTO code_store_item (id, code_store_type_id, caption, created_by, created_on, modified_by, modified_on)
VALUES (706, 7, '{"hu":"csak super admin", "en":"only super admin"}', 2, NOW(), 2, NOW());

INSERT INTO code_store_item (id, code_store_type_id, caption, created_by, created_on, modified_by, modified_on)
VALUES (708, 7, '{"hu":"rendszer", "en":"system"}', 2, NOW(), 2, NOW());