-- CREATE TABLE code_store_type (
-- 	id SERIAL PRIMARY KEY,
-- 	caption JSONB NOT NULL,
-- 	expandable BOOLEAN NOT NULL DEFAULT FALSE,
-- 	enabled BOOLEAN NOT NULL DEFAULT TRUE,
-- 	created_by INT NOT NULL REFERENCES auth_user(id),
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user(id),
-- 	modified_on TIMESTAMP NOT NULL
-- );
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (1, '{"hu":"felhasználói jogosultság", "en":"user role"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (2, '{"hu":"auth. token típus", "en":"auth token type"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (3, '{"hu":"fájlleíró státusza", "en":"file descriptor status"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (4, '{"hu":"email státusza", "en":"email status"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (5, '{"hu":"email sablon típusa", "en":"email template type"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (6, '{"hu":"fájl elhelyezés típusa", "en":"file location type"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (7, '{"hu":"fájl elérés (security) típusa", "en":"file security type"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (8, '{"hu":"kontakt adat típusa", "en":"contact address type"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (9, '{"hu":"földrajzi cím típusa", "en":"geo address type"}', 2, NOW(), 2, NOW());
--
-- INSERT INTO code_store_type (id, caption, created_by, created_on, modified_by, modified_on)
-- VALUES (10, '{"hu":"földrajzi adatok típusa", "en":"geo data type"}', 2, NOW(), 2, NOW());
--
-- SELECT SETVAL('code_store_type_id_seq', 500);

CREATE TABLE [dbo].[code_store_type](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [caption] [nvarchar](max) NOT NULL,
    [expandable] [bit] NOT NULL,
    [enabled] [bit] NOT NULL,
    [created_by] [int] NOT NULL,
    [created_on] [datetime] NOT NULL,
    [modified_by] [int] NOT NULL,
    [modified_on] [datetime] NOT NULL,
    CONSTRAINT [code_store_type_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    GO

ALTER TABLE [dbo].[code_store_type] ADD  CONSTRAINT [DF_code_store_type_expandable]  DEFAULT ((0)) FOR [expandable]
    GO

ALTER TABLE [dbo].[code_store_type] ADD  CONSTRAINT [DF_code_store_type_enabled]  DEFAULT ((1)) FOR [enabled]
    GO

ALTER TABLE [dbo].[code_store_type]  WITH CHECK ADD  CONSTRAINT [code_store_type_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[code_store_type] CHECK CONSTRAINT [code_store_type_created_by_fkey]
    GO

ALTER TABLE [dbo].[code_store_type]  WITH CHECK ADD  CONSTRAINT [code_store_type_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[code_store_type] CHECK CONSTRAINT [code_store_type_modified_by_fkey]
    GO

SET IDENTITY_INSERT [dbo].[code_store_type] ON;

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (1, N'{"hu":"felhasználói jogosultság", "en":"user role"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (2, N'{"hu":"auth. token típus", "en":"auth token type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (3, N'{"hu":"fájlleíró státusza", "en":"file descriptor status"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (4, N'{"hu":"email státusza", "en":"email status"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (5, N'{"hu":"email sablon típusa", "en":"email template type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (6, N'{"hu":"fájl elhelyezés típusa", "en":"file location type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (7, N'{"hu":"fájl elérés (security) típusa", "en":"file security type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (8, N'{"hu":"kontakt adat típusa", "en":"contact address type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (9, N'{"hu":"földrajzi cím típusa", "en":"geo address type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[code_store_type] (id, caption, expandable, enabled, created_by, created_on, modified_by, modified_on)
VALUES (10, N'{"hu":"földrajzi adatok típusa", "en":"geo data type"}', 0, 1, 2, GETDATE(), 2, GETDATE());

SET IDENTITY_INSERT [dbo].[code_store_type] OFF;

DBCC CHECKIDENT ([code_store_type], RESEED, 499);