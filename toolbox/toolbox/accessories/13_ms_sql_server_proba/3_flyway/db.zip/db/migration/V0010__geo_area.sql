-- CREATE TABLE geo_area (
-- 	id SERIAL PRIMARY KEY,
-- 	geo_area_type INT NOT NULL REFERENCES code_store_item(id),
-- 	geo_area_name VARCHAR(100) NOT NULL,
-- 	geo_area_url_name VARCHAR(100) NOT NULL,
-- 	parent_area INT
-- );
-- 
-- CREATE INDEX ON geo_area (lower(geo_area_url_name));
-- CREATE INDEX ON geo_area (parent_area);

CREATE TABLE [dbo].[geo_area](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [geo_area_type] [int] NOT NULL,
    [geo_area_name] [nvarchar](100) NOT NULL,
    [geo_area_url_name] [nvarchar](100) NOT NULL,
    [parent_area] [int] NULL,
    CONSTRAINT [geo_area_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
    GO

ALTER TABLE [dbo].[geo_area]  WITH CHECK ADD  CONSTRAINT [geo_area_geo_area_type_fkey] FOREIGN KEY([geo_area_type])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[geo_area] CHECK CONSTRAINT [geo_area_geo_area_type_fkey]
    GO