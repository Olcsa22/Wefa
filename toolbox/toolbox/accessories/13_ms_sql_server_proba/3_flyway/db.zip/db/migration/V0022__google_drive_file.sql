-- CREATE TABLE GOOGLE_DRIVE_FILE (
-- 	id SERIAL PRIMARY KEY,
-- 	tenant_id INT NOT NULL REFERENCES TENANT(id),
-- 	file_id INTEGER NOT NULL REFERENCES file_descriptor(id) UNIQUE,
-- 	priority INT NOT NULL,
-- 	web_view_url VARCHAR(150) NOT NULL,
-- 	google_drive_id VARCHAR(100),
-- 	anyone_with_link BOOLEAN,
-- 	status INT NOT NULL REFERENCES CODE_STORE_ITEM(id),
-- 	created_by INTEGER NOT NULL REFERENCES AUTH_USER(id),
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INTEGER NOT NULL REFERENCES AUTH_USER(id),
-- 	modified_on TIMESTAMP NOT NULL
-- );
--
-- CREATE INDEX ON GOOGLE_DRIVE_FILE (tenant_id);

CREATE TABLE [dbo].[google_drive_file](
                                    [id] [int] IDENTITY(1,1) NOT NULL,
                                    [tenant_id] [int] NOT NULL,
                                    [file_id] [int] NOT NULL,
                                    [priority] [int] NOT NULL,
--                                     [public_url] [varchar](1000) NULL,
--                                     [remote_id] [varchar](100) NULL,
                                    [web_view_url] [nvarchar](150) NULL,
                                    [google_drive_id] [nvarchar](100) NULL,
                                    [anyone_with_link] [bit] NULL,
                                    [status] [int] NOT NULL,
                                    [created_by] [int] NOT NULL,
                                    [created_on] [datetime] NOT NULL,
                                    [modified_by] [int] NOT NULL,
                                    [modified_on] [datetime] NOT NULL,

--                                     [attempt] [int] NULL,
--                                     [anyone_with_link_requested] [bit] NULL,
--                                     [remote_provider_type] [int] NOT NULL,
                                    CONSTRAINT [google_drive_file_pkey] PRIMARY KEY CLUSTERED
                                        (
                                         [id] ASC
                                            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
                                    CONSTRAINT [google_drive_file_file_id_key] UNIQUE NONCLUSTERED
                                        (
                                         [file_id] ASC
                                            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ALTER TABLE [dbo].[google_drive_file] ADD  CONSTRAINT [DF_google_drive_file_attempt]  DEFAULT ((0)) FOR [attempt]
-- GO

-- ALTER TABLE [dbo].[google_drive_file] ADD  CONSTRAINT [DF_google_drive_file_anyone_with_link_requested]  DEFAULT ((0)) FOR [anyone_with_link_requested]
-- GO

ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [google_drive_file_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [google_drive_file_created_by_fkey]
GO

ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [google_drive_file_file_id_fkey] FOREIGN KEY([file_id])
    REFERENCES [dbo].[file_descriptor] ([id])
GO

ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [google_drive_file_file_id_fkey]
GO

ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [google_drive_file_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [google_drive_file_modified_by_fkey]
GO

ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [google_drive_file_status_fkey] FOREIGN KEY([status])
    REFERENCES [dbo].[code_store_item] ([id])
GO

ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [google_drive_file_status_fkey]
GO

ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [google_drive_file_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [google_drive_file_tenant_id_fkey]
GO

ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [priority_fkey] FOREIGN KEY([priority])
    REFERENCES [dbo].[code_store_item] ([id])
GO

ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [priority_fkey]
GO

-- ALTER TABLE [dbo].[google_drive_file]  WITH CHECK ADD  CONSTRAINT [google_drive_file_remote_provider_type_fkey] FOREIGN KEY([remote_provider_type])
--     REFERENCES [dbo].[code_store_item] ([id])
-- GO
--
-- ALTER TABLE [dbo].[google_drive_file] CHECK CONSTRAINT [google_drive_file_remote_provider_type_fkey]
-- GO
