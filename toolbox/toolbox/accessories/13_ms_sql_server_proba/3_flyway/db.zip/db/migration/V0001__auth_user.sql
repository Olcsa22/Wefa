-- CREATE TABLE auth_user (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
-- 	username nvarchar(100) NOT NULL,
-- 	superior INT REFERENCES auth_user(id),
-- 	note nvarchar(160),
-- 	enabled BOOLEAN NOT NULL DEFAULT FALSE,
-- 	user_roles JSONB NOT NULL DEFAULT '[]',
-- 	anonymized_deleted BOOLEAN DEFAULT FALSE,
-- 	additional_data1 nvarchar(50),
-- 	additional_data2 nvarchar(50),
-- 	created_by INT NOT NULL REFERENCES auth_user,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user,
-- 	modified_on TIMESTAMP NOT NULL,
-- 	UNIQUE(tenant_id, username) DEFERRABLE INITIALLY IMMEDIATE
-- );
--
-- INSERT INTO auth_user (tenant_id, id, username, enabled, user_roles, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 1, 'admin', true, '[100, 102, 104, 106, 108, 110]', 1, NOW(), 1, NOW());
--
-- INSERT INTO auth_user (tenant_id, id, username, enabled, user_roles, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 2, 'system', true, '[]', 2, NOW(), 2, NOW());
--
-- INSERT INTO auth_user (tenant_id, id, username, enabled, user_roles, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 3, 'anonymous', true, '[]', 2, NOW(), 2, NOW());
--
-- SELECT SETVAL('auth_user_id_seq', 10);
--
-- CREATE TABLE auth_user_password (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
-- 	user_id INT NOT NULL REFERENCES auth_user(id),
-- 	password nvarchar(100) NOT NULL,
-- 	UNIQUE(user_id) DEFERRABLE INITIALLY IMMEDIATE
-- );
--
-- CREATE INDEX ON auth_user_password (tenant_id);
--
-- INSERT INTO auth_user_password (tenant_id, id, user_id, password)
-- VALUES (1, 1, 1, '$2a$12$XEmDBxKAdSwQHN0aHLoqk.pexvwH8ZLW9Za3J06vIcWlNINSegojm');
--
-- SELECT SETVAL('auth_user_password_id_seq', 10);
--
-- CREATE TABLE auth_user_sso (
-- 	id SERIAL PRIMARY KEY,
-- 	user_id INT NOT NULL REFERENCES auth_user(id),
-- 	sso_id nvarchar(100) NOT NULL,
-- 	sso_type nvarchar(50),
-- 	UNIQUE(user_id) DEFERRABLE INITIALLY IMMEDIATE
-- );
--
-- CREATE UNIQUE INDEX ON auth_user_sso (LOWER(sso_id));
--
-- CREATE TABLE auth_user_info (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
-- 	user_id INT NOT NULL REFERENCES auth_user(id),
-- 	date_of_birth DATE,
-- 	email nvarchar(100) NOT NULL,
-- 	title nvarchar(50),
-- 	family_name nvarchar(100),
-- 	given_name nvarchar(100),
-- 	job_title nvarchar(50),
-- 	phone_number nvarchar(100),
-- 	created_by INT NOT NULL REFERENCES auth_user,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user,
-- 	modified_on TIMESTAMP NOT NULL,
-- 	UNIQUE(user_id) DEFERRABLE INITIALLY IMMEDIATE
-- );
--
-- INSERT INTO auth_user_info (tenant_id, id, user_id, given_name, family_name, email, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 1, 1, 'Admin', 'Super', 'super-admin@example.com', 1, NOW(), 1, NOW());
--
-- INSERT INTO auth_user_info (tenant_id, id, user_id, given_name, family_name, email, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 2, 2, 'System', 'System', 'system@example.com', 2, NOW(), 2, NOW());
--
-- SELECT SETVAL('auth_user_info_id_seq', 10);
--
-- CREATE UNIQUE INDEX ON auth_user_info (user_id);
-- CREATE INDEX ON auth_user_info (lower(given_name));
-- CREATE INDEX ON auth_user_info (lower(family_name));
-- CREATE INDEX ON auth_user_info (lower(email));
--
-- CREATE TABLE auth_user_key_value_settings (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
-- 	user_id INT NOT NULL REFERENCES auth_user(id),
-- 	key nvarchar(50) NOT NULL,
-- 	value nvarchar(50) NOT NULL,
-- 	created_by INT NOT NULL REFERENCES auth_user,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user,
-- 	modified_on TIMESTAMP NOT NULL
-- );
--
-- CREATE UNIQUE INDEX ON auth_user_key_value_settings (user_id, lower(key));

CREATE TABLE [dbo].[auth_user](
    [tenant_id] [int] NOT NULL,
    [id] [int] IDENTITY(1,1) NOT NULL,
    [username] [nvarchar](100) NOT NULL,
    [superior] [int] NULL,
    [note] [nvarchar](160) NULL,
    [enabled] [bit] NOT NULL,
    [user_roles] [nvarchar](max) NOT NULL,
    [anonymized_deleted] [bit] NULL,
    [additional_data1] [nvarchar](50) NULL,
    [additional_data2] [nvarchar](50) NULL,
    [created_by] [int] NOT NULL,
    [created_on] [datetime] NOT NULL,
    [modified_by] [int] NOT NULL,
    [modified_on] [datetime] NOT NULL,
    [profile_img] [int] NULL,
    [parent_id] [int] NULL,
    CONSTRAINT [auth_user_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    GO

ALTER TABLE [dbo].[auth_user] ADD  CONSTRAINT [DF_auth_user_enabled]  DEFAULT ((0)) FOR [enabled]
GO

ALTER TABLE [dbo].[auth_user] ADD  CONSTRAINT [DF_auth_user_user_roles]  DEFAULT ('[]') FOR [user_roles]
GO

ALTER TABLE [dbo].[auth_user] ADD  CONSTRAINT [DF_auth_user_anonymized_deleted]  DEFAULT ((0)) FOR [anonymized_deleted]
GO

ALTER TABLE [dbo].[auth_user]  WITH CHECK ADD  CONSTRAINT [auth_user_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[auth_user] CHECK CONSTRAINT [auth_user_created_by_fkey]
GO

ALTER TABLE [dbo].[auth_user]  WITH CHECK ADD  CONSTRAINT [auth_user_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[auth_user] CHECK CONSTRAINT [auth_user_modified_by_fkey]
GO

ALTER TABLE [dbo].[auth_user]  WITH CHECK ADD  CONSTRAINT [auth_user_parent_id_fkey] FOREIGN KEY([parent_id])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[auth_user] CHECK CONSTRAINT [auth_user_parent_id_fkey]
GO

--TODO:
-- ALTER TABLE [dbo].[auth_user]  WITH CHECK ADD  CONSTRAINT [auth_user_profile_img_fkey] FOREIGN KEY([profile_img])
--     REFERENCES [dbo].[file_descriptor] ([id])
--     GO

--TODO:
-- ALTER TABLE [dbo].[auth_user] CHECK CONSTRAINT [auth_user_profile_img_fkey]
--     GO

ALTER TABLE [dbo].[auth_user]  WITH CHECK ADD  CONSTRAINT [auth_user_superior_fkey] FOREIGN KEY([superior])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[auth_user] CHECK CONSTRAINT [auth_user_superior_fkey]
GO

ALTER TABLE [dbo].[auth_user]  WITH CHECK ADD  CONSTRAINT [auth_user_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
    GO

ALTER TABLE [dbo].[auth_user] CHECK CONSTRAINT [auth_user_tenant_id_fkey]
GO

SET IDENTITY_INSERT [dbo].[auth_user] ON;

INSERT INTO [dbo].[auth_user] (tenant_id, id, username, enabled, user_roles, created_by, created_on, modified_by, modified_on)
VALUES (1, 1, 'admin', 1, '[100, 102, 104, 106, 108, 110]', 1, GETDATE(), 1, GETDATE());

INSERT INTO [dbo].[auth_user] (tenant_id, id, username, enabled, user_roles, created_by, created_on, modified_by, modified_on)
VALUES (1, 2, 'system', 1, '[]', 2, GETDATE(), 2, GETDATE());

INSERT INTO [dbo].[auth_user] (tenant_id, id, username, enabled, user_roles, created_by, created_on, modified_by, modified_on)
VALUES (1, 3, 'anonymous', 1, '[]', 2, GETDATE(), 2, GETDATE());

SET IDENTITY_INSERT [dbo].[auth_user] OFF;

DBCC CHECKIDENT ([auth_user], RESEED, 9);

-- auth_user_password

CREATE TABLE [dbo].[auth_user_password](
                                           [tenant_id] [int] NOT NULL,
                                           [id] [int] IDENTITY(1,1) NOT NULL,
                                           [user_id] [int] NOT NULL,
                                           [password] [nvarchar](100) NOT NULL,
                                           [two_factor_type] [int] NULL,
                                           [two_factor_enabled] [bit] NULL,
                                           [two_factor_value] [nvarchar](max) NULL,
                                           CONSTRAINT [auth_user_password_pkey] PRIMARY KEY CLUSTERED
                                               (
                                                [id] ASC
                                                   )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
                                           CONSTRAINT [auth_user_password_user_id_key] UNIQUE NONCLUSTERED
                                               (
                                                [user_id] ASC
                                                   )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[auth_user_password]  WITH CHECK ADD  CONSTRAINT [auth_user_password_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[auth_user_password] CHECK CONSTRAINT [auth_user_password_tenant_id_fkey]
GO

--TODO:
-- ALTER TABLE [dbo].[auth_user_password]  WITH CHECK ADD  CONSTRAINT [auth_user_password_two_factor_type_fkey] FOREIGN KEY([two_factor_type])
--     REFERENCES [dbo].[code_store_item] ([id])
-- GO

--TODO:
-- ALTER TABLE [dbo].[auth_user_password] CHECK CONSTRAINT [auth_user_password_two_factor_type_fkey]
-- GO

ALTER TABLE [dbo].[auth_user_password]  WITH CHECK ADD  CONSTRAINT [auth_user_password_user_id_fkey] FOREIGN KEY([user_id])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_password] CHECK CONSTRAINT [auth_user_password_user_id_fkey]
GO

SET IDENTITY_INSERT [dbo].[auth_user_password] ON;

INSERT INTO [dbo].[auth_user_password] (tenant_id, id, user_id, password)
VALUES (1, 1, 1, '$2a$12$XEmDBxKAdSwQHN0aHLoqk.pexvwH8ZLW9Za3J06vIcWlNINSegojm');

SET IDENTITY_INSERT [dbo].[auth_user_password] OFF;

DBCC CHECKIDENT ([auth_user_password], RESEED, 9);

-- auth_user_sso

CREATE TABLE [dbo].[auth_user_sso](
                                      [id] [int] IDENTITY(1,1) NOT NULL,
                                      [user_id] [int] NOT NULL,
                                      [sso_id] [nvarchar](100) NOT NULL,
                                      [sso_type] [nvarchar](50) NULL,
                                      CONSTRAINT [auth_user_sso_pkey] PRIMARY KEY CLUSTERED
                                          (
                                           [id] ASC
                                              )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
                                      CONSTRAINT [auth_user_sso_user_id_key] UNIQUE NONCLUSTERED
                                          (
                                           [user_id] ASC
                                              )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[auth_user_sso]  WITH CHECK ADD  CONSTRAINT [auth_user_sso_user_id_fkey] FOREIGN KEY([user_id])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_sso] CHECK CONSTRAINT [auth_user_sso_user_id_fkey]
GO

-- auth_user_info

CREATE TABLE [dbo].[auth_user_info](
                                       [tenant_id] [int] NOT NULL,
                                       [id] [int] IDENTITY(1,1) NOT NULL,
                                       [user_id] [int] NOT NULL,
                                       [date_of_birth] [date] NULL,
                                       [email] [nvarchar](100) NOT NULL,
                                       [title] [nvarchar](50) NULL,
                                       [family_name] [nvarchar](100) NULL,
                                       [given_name] [nvarchar](100) NULL,
                                       [job_title] [nvarchar](50) NULL,
                                       [phone_number] [nvarchar](100) NULL,
                                       [created_by] [int] NOT NULL,
                                       [created_on] [datetime] NOT NULL,
                                       [modified_by] [int] NOT NULL,
                                       [modified_on] [datetime] NOT NULL,
                                       CONSTRAINT [auth_user_info_pkey] PRIMARY KEY CLUSTERED
                                           (
                                            [id] ASC
                                               )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
                                       CONSTRAINT [auth_user_info_user_id_key] UNIQUE NONCLUSTERED
                                           (
                                            [user_id] ASC
                                               )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[auth_user_info]  WITH CHECK ADD  CONSTRAINT [auth_user_info_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_info] CHECK CONSTRAINT [auth_user_info_created_by_fkey]
GO

ALTER TABLE [dbo].[auth_user_info]  WITH CHECK ADD  CONSTRAINT [auth_user_info_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_info] CHECK CONSTRAINT [auth_user_info_modified_by_fkey]
GO

ALTER TABLE [dbo].[auth_user_info]  WITH CHECK ADD  CONSTRAINT [auth_user_info_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[auth_user_info] CHECK CONSTRAINT [auth_user_info_tenant_id_fkey]
GO

ALTER TABLE [dbo].[auth_user_info]  WITH CHECK ADD  CONSTRAINT [auth_user_info_user_id_fkey] FOREIGN KEY([user_id])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_info] CHECK CONSTRAINT [auth_user_info_user_id_fkey]
GO

SET IDENTITY_INSERT [dbo].[auth_user_info] ON;

INSERT INTO [dbo].[auth_user_info] (tenant_id, id, user_id, given_name, family_name, email, created_by, created_on, modified_by, modified_on)
VALUES (1, 1, 1, 'Admin', 'Super', 'super-admin@example.com', 1, GETDATE(), 1, GETDATE());

INSERT INTO [dbo].[auth_user_info] (tenant_id, id, user_id, given_name, family_name, email, created_by, created_on, modified_by, modified_on)
VALUES (1, 2, 2, 'System', 'System', 'system@example.com', 2, GETDATE(), 2, GETDATE());

SET IDENTITY_INSERT [dbo].[auth_user_info] OFF;

DBCC CHECKIDENT ([auth_user_info], RESEED, 9);

-- auth_user_key_value_settings

CREATE TABLE [dbo].[auth_user_key_value_settings](
                                                     [tenant_id] [int] NOT NULL,
                                                     [id] [int] IDENTITY(1,1) NOT NULL,
                                                     [user_id] [int] NOT NULL,
                                                     [kv_key] [nvarchar](50) NOT NULL,
                                                     [kv_value] [nvarchar](100) NULL,
                                                     [created_by] [int] NOT NULL,
                                                     [created_on] [datetime] NOT NULL,
                                                     [modified_by] [int] NOT NULL,
                                                     [modified_on] [datetime] NOT NULL,
                                                     [kv_long_text] [nvarchar](max) NULL,
                                                     [manual_edit_allowed] [bit] NOT NULL,
                                                     CONSTRAINT [auth_user_key_value_settings_pkey] PRIMARY KEY CLUSTERED
                                                         (
                                                          [id] ASC
                                                             )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[auth_user_key_value_settings] ADD  CONSTRAINT [DF_auth_user_key_value_settings_manual_edit_allowed]  DEFAULT ((1)) FOR [manual_edit_allowed]
GO

ALTER TABLE [dbo].[auth_user_key_value_settings]  WITH CHECK ADD  CONSTRAINT [auth_user_key_value_settings_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_key_value_settings] CHECK CONSTRAINT [auth_user_key_value_settings_created_by_fkey]
GO

ALTER TABLE [dbo].[auth_user_key_value_settings]  WITH CHECK ADD  CONSTRAINT [auth_user_key_value_settings_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
GO

ALTER TABLE [dbo].[auth_user_key_value_settings] CHECK CONSTRAINT [auth_user_key_value_settings_modified_by_fkey]
GO

ALTER TABLE [dbo].[auth_user_key_value_settings]  WITH CHECK ADD  CONSTRAINT [auth_user_key_value_settings_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[auth_user_key_value_settings] CHECK CONSTRAINT [auth_user_key_value_settings_tenant_id_fkey]
GO

ALTER TABLE [dbo].[auth_user_key_value_settings]  WITH CHECK ADD  CONSTRAINT [auth_user_key_value_settings_user_id_fkey] FOREIGN KEY([user_id])
    REFERENCES [dbo].[auth_user] ([id])
GO