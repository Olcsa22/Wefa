INSERT INTO code_store_item (id, code_store_type_id, caption, created_by, created_on, modified_by, modified_on)
VALUES (312, 3, '{"hu":"törölve", "en":"deleted"}', 2, NOW(), 2, NOW());