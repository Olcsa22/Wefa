-- ALTER TABLE file_descriptor DROP COLUMN description;
--
-- ALTER TABLE file_descriptor
-- ADD COLUMN meta_1 VARCHAR(150),
-- ADD COLUMN meta_2 VARCHAR(150),
-- ADD COLUMN meta_3 INT REFERENCES CODE_STORE_ITEM(id),
-- ADD COLUMN note VARCHAR(150);

ALTER TABLE [dbo].[file_descriptor] DROP COLUMN [description]

ALTER TABLE [dbo].[file_descriptor] ADD meta_1 [nvarchar](150) NULL;
ALTER TABLE [dbo].[file_descriptor] ADD meta_2 [nvarchar](150) NULL;
ALTER TABLE [dbo].[file_descriptor] ADD meta_3 [int] NULL;
ALTER TABLE [dbo].[file_descriptor] ADD note [nvarchar](150) NULL;

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_meta_3_fkey] FOREIGN KEY([meta_3])
    REFERENCES [dbo].[code_store_item] ([id])
GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_meta_3_fkey]
GO

