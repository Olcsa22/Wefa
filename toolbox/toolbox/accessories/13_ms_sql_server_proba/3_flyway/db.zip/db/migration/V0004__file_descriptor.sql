-- CREATE TABLE file_descriptor (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
-- 	location_type INT NOT NULL REFERENCES code_store_item(id),
-- 	security_type INT NOT NULL REFERENCES code_store_item(id),
-- 	filename VARCHAR(100),
-- 	file_path VARCHAR(100) NOT NULL,
-- 	mime_type VARCHAR(100),
-- 	file_size BIGINT,
-- 	description JSONB,
-- 	hash_value VARCHAR(64),
-- 	gid UUID NOT NULL,
-- 	status INT NOT NULL REFERENCES code_store_item(id),
-- 	created_by INT NOT NULL REFERENCES auth_user(id),
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user(id),
-- 	modified_on TIMESTAMP NOT NULL,
-- 	UNIQUE(file_path)
-- );
-- 
-- CREATE UNIQUE INDEX ON file_descriptor (lower(file_path));
-- CREATE INDEX ON file_descriptor (tenant_id);
-- CREATE INDEX ON file_descriptor (gid);
-- CREATE INDEX ON file_descriptor (lower(mime_type));
-- CREATE INDEX ON file_descriptor (lower(filename));
-- 
-- ALTER TABLE auth_user ADD COLUMN profile_img INT REFERENCES file_descriptor(id);

CREATE TABLE [dbo].[file_descriptor](
    [tenant_id] [int] NOT NULL,
    [id] [int] IDENTITY(1,1) NOT NULL,
    [location_type] [int] NOT NULL,
    [security_type] [int] NOT NULL,
    [filename] [nvarchar](100) NULL,
    [file_path] [nvarchar](1024) NOT NULL,
    [mime_type] [nvarchar](100) NULL,
    [file_size] [bigint] NULL,
    [description] [nvarchar](max),
    [hash_value] [nvarchar](64) NULL,
    [gid] [uniqueidentifier] NOT NULL,
    [status] [int] NOT NULL,
    [created_by] [int] NOT NULL,
    [created_on] [datetime] NOT NULL,
    [modified_by] [int] NOT NULL,
    [modified_on] [datetime] NOT NULL,
    [meta_3_type] [int] NULL,
    [remote_only] [bit] NULL,
    [parent_id] [int] NULL,
    [child_type] [int] NULL,
    [meta_4] [nvarchar](max) NULL,
    [locked_by] [int] NULL,
    [locked_on] [datetime] NULL,
    CONSTRAINT [file_descriptor_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [file_descriptor_file_path_key] UNIQUE NONCLUSTERED
(
[file_path] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_child_type_fkey] FOREIGN KEY([child_type])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_child_type_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_created_by_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_location_type_fkey] FOREIGN KEY([location_type])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_location_type_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_locked_by_fkey] FOREIGN KEY([locked_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_locked_by_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_meta_3_type_fkey] FOREIGN KEY([meta_3_type])
    REFERENCES [dbo].[code_store_type] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_meta_3_type_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_modified_by_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_parent_id_fkey] FOREIGN KEY([parent_id])
    REFERENCES [dbo].[file_descriptor] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_parent_id_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_security_type_fkey] FOREIGN KEY([security_type])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_security_type_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_status_fkey] FOREIGN KEY([status])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_status_fkey]
    GO

ALTER TABLE [dbo].[file_descriptor]  WITH CHECK ADD  CONSTRAINT [file_descriptor_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
    GO

ALTER TABLE [dbo].[file_descriptor] CHECK CONSTRAINT [file_descriptor_tenant_id_fkey]
    GO