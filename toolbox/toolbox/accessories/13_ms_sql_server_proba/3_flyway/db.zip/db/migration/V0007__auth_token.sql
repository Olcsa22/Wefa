﻿-- CREATE TABLE auth_token (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
--  	token_type INT NOT NULL REFERENCES code_store_item(id),
-- 	token VARCHAR(100) NOT NULL,
-- 	valid_until TIMESTAMP NOT NULL,
-- 	resource_id1 INT NOT NULL,
-- 	resource_id2 INT,
-- 	note1 VARCHAR(200),
-- 	note2 VARCHAR(200),
-- 	note3 VARCHAR(200),
-- 	created_by INT NOT NULL REFERENCES auth_user,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user,
-- 	modified_on TIMESTAMP NOT NULL
-- );
--
-- CREATE INDEX ON auth_token (tenant_id);
-- CREATE INDEX ON auth_token (token_type);
-- CREATE UNIQUE INDEX ON auth_token (lower(token)); -- itt globálisan kell unique legyen a token

CREATE TABLE [dbo].[auth_token](
    [tenant_id] [int] NOT NULL,
    [id] [int] IDENTITY(1,1) NOT NULL,
    [token_type] [int] NOT NULL,
    [token] [nvarchar](100) NOT NULL,
    [valid_until] [datetime] NOT NULL,
    [resource_id1] [int] NOT NULL,
    [resource_id2] [int] NULL,
    [note1] [nvarchar](200) NULL,
    [note2] [nvarchar](200) NULL,
    [note3] [nvarchar](200) NULL,
    [created_by] [int] NOT NULL,
    [created_on] [datetime] NOT NULL,
    [modified_by] [int] NOT NULL,
    [modified_on] [datetime] NOT NULL,
    CONSTRAINT [auth_token_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
    GO

ALTER TABLE [dbo].[auth_token]  WITH CHECK ADD  CONSTRAINT [auth_token_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[auth_token] CHECK CONSTRAINT [auth_token_created_by_fkey]
    GO

ALTER TABLE [dbo].[auth_token]  WITH CHECK ADD  CONSTRAINT [auth_token_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[auth_token] CHECK CONSTRAINT [auth_token_modified_by_fkey]
    GO

ALTER TABLE [dbo].[auth_token]  WITH CHECK ADD  CONSTRAINT [auth_token_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
    GO

ALTER TABLE [dbo].[auth_token] CHECK CONSTRAINT [auth_token_tenant_id_fkey]
    GO

ALTER TABLE [dbo].[auth_token]  WITH CHECK ADD  CONSTRAINT [auth_token_token_type_fkey] FOREIGN KEY([token_type])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[auth_token] CHECK CONSTRAINT [auth_token_token_type_fkey]
    GO