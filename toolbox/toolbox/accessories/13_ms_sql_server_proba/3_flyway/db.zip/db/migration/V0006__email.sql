-- CREATE TABLE email (
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	id SERIAL PRIMARY KEY,
-- 	from_email VARCHAR(255),
-- 	to_email VARCHAR(255) NOT NULL,
-- 	subject VARCHAR(255) NOT NULL,
-- 	body TEXT NOT NULL,
-- 	is_plain_text BOOLEAN NOT NULL DEFAULT FALSE,
-- 	status INT NOT NULL REFERENCES code_store_item(id),
-- 	attempt INT NOT NULL,
-- 	error_message TEXT,
-- 	created_by INT NOT NULL REFERENCES auth_user,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT NOT NULL REFERENCES auth_user,
-- 	modified_on TIMESTAMP NOT NULL
-- );
-- 
-- CREATE INDEX ON email (tenant_id);
-- CREATE INDEX ON email (status);
-- CREATE INDEX ON email (from_email);
-- CREATE INDEX ON email (to_email);

CREATE TABLE [dbo].[email](
    [tenant_id] [int] NOT NULL,
    [id] [int] IDENTITY(1,1) NOT NULL,
    [from_email] [nvarchar](255) NULL,
    [to_email] [nvarchar](255) NOT NULL,
    [subject] [nvarchar](255) NOT NULL,
    [body] [nvarchar](max) NOT NULL,
    [is_plain_text] [bit] NOT NULL,
    [status] [int] NOT NULL,
    [attempt] [int] NOT NULL,
    [error_message] [nvarchar](max) NULL,
    [created_by] [int] NOT NULL,
    [created_on] [datetime] NOT NULL,
    [modified_by] [int] NOT NULL,
    [modified_on] [datetime] NOT NULL,
    [file_ids] [nvarchar](max) NULL,
    CONSTRAINT [email_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    GO

ALTER TABLE [dbo].[email] ADD  CONSTRAINT [DF_email_is_plain_text]  DEFAULT ((0)) FOR [is_plain_text]
    GO

ALTER TABLE [dbo].[email]  WITH CHECK ADD  CONSTRAINT [email_created_by_fkey] FOREIGN KEY([created_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[email] CHECK CONSTRAINT [email_created_by_fkey]
    GO

ALTER TABLE [dbo].[email]  WITH CHECK ADD  CONSTRAINT [email_modified_by_fkey] FOREIGN KEY([modified_by])
    REFERENCES [dbo].[auth_user] ([id])
    GO

ALTER TABLE [dbo].[email] CHECK CONSTRAINT [email_modified_by_fkey]
    GO

ALTER TABLE [dbo].[email]  WITH CHECK ADD  CONSTRAINT [email_status_fkey] FOREIGN KEY([status])
    REFERENCES [dbo].[code_store_item] ([id])
    GO

ALTER TABLE [dbo].[email] CHECK CONSTRAINT [email_status_fkey]
    GO

ALTER TABLE [dbo].[email]  WITH CHECK ADD  CONSTRAINT [email_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
    GO

ALTER TABLE [dbo].[email] CHECK CONSTRAINT [email_tenant_id_fkey]
    GO