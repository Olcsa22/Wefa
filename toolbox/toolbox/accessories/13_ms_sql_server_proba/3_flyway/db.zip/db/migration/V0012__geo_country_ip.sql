-- CREATE TABLE geo_country_ip (
--   id SERIAL PRIMARY KEY,
--   country_name VARCHAR(150) not null,
--   country_code character(2),
--   start_ip VARCHAR(15) not null,
--   end_ip VARCHAR(15) not null,
--   netmask VARCHAR(15) not null
-- );
--
-- CREATE INDEX ON geo_country_ip(start_ip, end_ip);
-- CREATE INDEX ON geo_country_ip(lower(country_name));
-- CREATE INDEX ON geo_country_ip(lower(country_code));

CREATE TABLE [dbo].[geo_country_ip](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [country_name] [nvarchar](150) NOT NULL,
    [country_code] [char](2) NULL,
    [start_ip] [nvarchar](15) NOT NULL,
    [end_ip] [nvarchar](15) NOT NULL,
    [netmask] [nvarchar](15) NOT NULL,
    CONSTRAINT [geo_country_ip_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
    GO