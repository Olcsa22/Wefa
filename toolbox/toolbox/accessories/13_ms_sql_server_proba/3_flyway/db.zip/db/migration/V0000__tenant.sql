-- CREATE TABLE tenant (
-- 	id SERIAL PRIMARY KEY,
-- 	name VARCHAR(50) NOT NULL,
-- 	enabled BOOLEAN NOT NULL DEFAULT TRUE,
-- 	anonymized_deleted BOOLEAN DEFAULT FALSE,
-- 	created_by INT,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT,
-- 	modified_on TIMESTAMP NOT NULL,
-- 	UNIQUE(name)
-- );
--
-- INSERT INTO tenant(id, name, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 'common-tenant', NULL, NOW(), NULL , NOW());
--
-- INSERT INTO tenant(id, name, created_by, created_on, modified_by, modified_on)
-- VALUES (2, 'lcu-tenant', NULL, NOW(), NULL , NOW());
--
-- SELECT SETVAL('tenant_id_seq', 10);
--
-- CREATE TABLE tenant_info (
-- 	id SERIAL PRIMARY KEY,
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	email VARCHAR(100) NOT NULL,
-- 	phone VARCHAR(30),
-- 	created_by INT,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT,
-- 	modified_on TIMESTAMP NOT NULL,
-- 	UNIQUE(tenant_id) DEFERRABLE INITIALLY IMMEDIATE
-- );
--
-- INSERT INTO tenant_info(id, tenant_id, email, phone, created_by, created_on, modified_by, modified_on)
-- VALUES (1, 1, 'example@example.com', NULL, NULL, NOW(), NULL , NOW());
--
-- INSERT INTO tenant_info(id, tenant_id, email, phone, created_by, created_on, modified_by, modified_on)
-- VALUES (2, 2, 'example@example.com', NULL, NULL, NOW(), NULL , NOW());
--
-- SELECT SETVAL('tenant_info_id_seq', 10);
--
-- CREATE INDEX ON tenant_info (email);
-- CREATE INDEX ON tenant_info (phone);
--
-- CREATE TABLE tenant_key_value_settings (
-- 	id SERIAL PRIMARY KEY,
-- 	tenant_id INT NOT NULL REFERENCES tenant(id),
-- 	key VARCHAR(50) NOT NULL,
-- 	value VARCHAR(50) NOT NULL,
-- 	created_by INT,
-- 	created_on TIMESTAMP NOT NULL,
-- 	modified_by INT,
-- 	modified_on TIMESTAMP NOT NULL
-- );
--
-- CREATE UNIQUE INDEX ON tenant_key_value_settings (tenant_id, lower(key));

CREATE TABLE [dbo].[tenant](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](50) NOT NULL,
    [enabled] [bit] NOT NULL,
    [anonymized_deleted] [bit] NULL,
    [created_by] [int] NULL,
    [created_on] [datetime] NOT NULL,
    [modified_by] [int] NULL,
    [modified_on] [datetime] NOT NULL,
    [brand] [nvarchar](50) NULL,
    CONSTRAINT [tenant_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [tenant_name_key] UNIQUE NONCLUSTERED
(
[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

ALTER TABLE [dbo].[tenant] ADD  CONSTRAINT [DF_tenant_enabled]  DEFAULT ((1)) FOR [enabled]
GO

ALTER TABLE [dbo].[tenant] ADD  CONSTRAINT [DF_tenant_anonymized_deleted]  DEFAULT ((0)) FOR [anonymized_deleted]
GO

SET IDENTITY_INSERT [dbo].[tenant] ON;

INSERT INTO [dbo].[tenant](id, name, enabled, created_by, created_on, modified_by, modified_on)
VALUES (1, 'common-tenant', 1, NULL, GETDATE(), NULL , GETDATE());

INSERT INTO [dbo].[tenant](id, name, enabled, created_by, created_on, modified_by, modified_on)
VALUES (2, 'lcu-tenant', 1, NULL, GETDATE(), NULL , GETDATE());

SET IDENTITY_INSERT [dbo].[tenant] OFF;

DBCC CHECKIDENT ([tenant], RESEED, 9);

-- tenant_info

CREATE TABLE [dbo].[tenant_info](
                                    [id] [int] IDENTITY(1,1) NOT NULL,
                                    [tenant_id] [int] NOT NULL,
                                    [email] [nvarchar](100) NOT NULL,
                                    [phone] [nvarchar](30) NULL,
                                    [created_by] [int] NULL,
                                    [created_on] [datetime] NOT NULL,
                                    [modified_by] [int] NULL,
                                    [modified_on] [datetime] NOT NULL,
                                    [company_tax_number] [nvarchar](50) NULL,
                                    [company_registration_number] [nvarchar](50) NULL,
                                    [company_bank_account_number] [nvarchar](50) NULL,
                                    [company_address_country] [char](2) NULL,
                                    [company_address_state] [nvarchar](50) NULL,
                                    [company_address_county] [nvarchar](50) NULL,
                                    [company_address_zip_code] [nvarchar](10) NULL,
                                    [company_address_details] [nvarchar](50) NULL,
                                    [contact_name] [nvarchar](50) NULL,
                                    [note] [nvarchar](500) NULL,
                                    [extra_data_1] [nvarchar](100) NULL,
                                    [extra_data_2] [nvarchar](100) NULL,
                                    [extra_data_3] [nvarchar](100) NULL,
                                    [extra_data_4] [int] NULL,
                                    [file_ids] [nvarchar](max) NULL,
                                    [file_ids_2] [nvarchar](max) NULL,
                                    [file_ids_3] [nvarchar](max) NULL,
                                    [company_name] [nvarchar](200) NULL,
                                    CONSTRAINT [tenant_info_pkey] PRIMARY KEY CLUSTERED
                                        (
                                         [id] ASC
                                            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
                                    CONSTRAINT [tenant_info_tenant_id_key] UNIQUE NONCLUSTERED
                                        (
                                         [tenant_id] ASC
                                            )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

--TODO:
-- ALTER TABLE [dbo].[tenant_info]  WITH CHECK ADD  CONSTRAINT [tenant_info_extra_data_4_fkey] FOREIGN KEY([extra_data_4])
--     REFERENCES [dbo].[code_store_item] ([id])
-- GO

--TODO:
-- ALTER TABLE [dbo].[tenant_info] CHECK CONSTRAINT [tenant_info_extra_data_4_fkey]
-- GO

ALTER TABLE [dbo].[tenant_info]  WITH CHECK ADD  CONSTRAINT [tenant_info_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[tenant_info] CHECK CONSTRAINT [tenant_info_tenant_id_fkey]
GO

SET IDENTITY_INSERT [dbo].[tenant_info] ON;

INSERT INTO [dbo].[tenant_info](id, tenant_id, email, phone, created_by, created_on, modified_by, modified_on)
VALUES (1, 1, 'example@example.com', NULL, NULL, GETDATE(), NULL , GETDATE());

INSERT INTO [dbo].[tenant_info](id, tenant_id, email, phone, created_by, created_on, modified_by, modified_on)
VALUES (2, 2, 'example@example.com', NULL, NULL, GETDATE(), NULL , GETDATE());

SET IDENTITY_INSERT [dbo].[tenant_info] OFF;

DBCC CHECKIDENT ([tenant_info], RESEED, 9);

-- tenant_key_value_settings

CREATE TABLE [dbo].[tenant_key_value_settings](
                                                  [id] [int] IDENTITY(1,1) NOT NULL,
                                                  [tenant_id] [int] NOT NULL,
                                                  [kv_key] [nvarchar](50) NOT NULL,
                                                  [kv_value] [nvarchar](100) NULL,
                                                  [created_by] [int] NULL,
                                                  [created_on] [datetime] NOT NULL,
                                                  [modified_by] [int] NULL,
                                                  [modified_on] [datetime] NOT NULL,
                                                  [kv_long_text] [nvarchar](max) NULL,
                                                  [manual_edit_allowed] [bit] NOT NULL,
                                                  CONSTRAINT [tenant_key_value_settings_pkey] PRIMARY KEY CLUSTERED
                                                      (
                                                       [id] ASC
                                                          )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[tenant_key_value_settings] ADD  CONSTRAINT [DF_tenant_key_value_settings_manual_edit_allowed]  DEFAULT ((1)) FOR [manual_edit_allowed]
GO

ALTER TABLE [dbo].[tenant_key_value_settings]  WITH CHECK ADD  CONSTRAINT [tenant_key_value_settings_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[tenant_key_value_settings] CHECK CONSTRAINT [tenant_key_value_settings_tenant_id_fkey]
GO

DBCC CHECKIDENT ([tenant_key_value_settings], RESEED, 9);