ALTER TABLE tenant_info RENAME COLUMN extra_data_5 TO file_ids;
ALTER TABLE tenant_info RENAME COLUMN extra_data_6 TO file_ids_2;
ALTER TABLE tenant_info RENAME COLUMN extra_data_7 TO file_ids_3;