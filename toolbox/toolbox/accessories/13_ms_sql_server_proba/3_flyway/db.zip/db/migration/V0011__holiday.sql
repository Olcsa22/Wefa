-- CREATE TABLE holiday ( -- Google Calendar-ból áthúzott ünnepnapok és hétvégi munkanapok
-- 	id SERIAL PRIMARY KEY,
-- 	dstart DATE NOT NULL, -- a nap (csak azért ...start mert a Google is így hívja)
-- 	summary VARCHAR(160),
-- 	workday BOOLEAN NOT NULL, -- hétvégi munkanapok esetén true
-- 	UNIQUE (dstart)
-- );

CREATE TABLE [dbo].[holiday](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [event_date] [date] NOT NULL,
    [summary] [nvarchar](160) NULL,
    [workday] [bit] NOT NULL,
    [event_country] [nvarchar](100) NULL,
    CONSTRAINT [holiday_pkey] PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [holiday_dstart_key] UNIQUE NONCLUSTERED
(
[event_date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
    GO