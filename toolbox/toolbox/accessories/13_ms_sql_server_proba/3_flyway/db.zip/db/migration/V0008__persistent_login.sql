﻿-- CREATE TABLE persistent_login (
-- 	series VARCHAR(64) PRIMARY KEY NOT NULL,
-- 	token_value VARCHAR(64) NOT NULL,
-- 	date TIMESTAMP NOT NULL,
-- 	username VARCHAR(100) NOT NULL -- REFERENCES auth_user(username)
-- );
--
-- CREATE INDEX ON persistent_login (lower(username));

CREATE TABLE [dbo].[persistent_login](
    [series] [nvarchar](64) NOT NULL,
    [token_value] [nvarchar](64) NOT NULL,
    [date] [datetime] NOT NULL,
    [username] [nvarchar](100) NOT NULL,
    CONSTRAINT [persistent_login_pkey] PRIMARY KEY CLUSTERED
(
[series] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
    GO