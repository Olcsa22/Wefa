ALTER TABLE google_drive_file
RENAME TO remote_file;