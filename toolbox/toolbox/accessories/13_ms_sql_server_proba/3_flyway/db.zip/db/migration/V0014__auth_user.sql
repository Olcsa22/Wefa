-- ALTER TABLE auth_user_sso ADD COLUMN tenant_id INT NOT NULL REFERENCES tenant(id);

ALTER TABLE [dbo].[auth_user_sso] ADD tenant_id [int] NOT NULL;

ALTER TABLE [dbo].[auth_user_sso]  WITH CHECK ADD  CONSTRAINT [auth_user_sso_tenant_id_fkey] FOREIGN KEY([tenant_id])
    REFERENCES [dbo].[tenant] ([id])
GO

ALTER TABLE [dbo].[auth_user_sso] CHECK CONSTRAINT [auth_user_sso_tenant_id_fkey]
GO