-- ALTER TABLE email_template DROP COLUMN tenant_id;

ALTER TABLE [dbo].[email_template]
    DROP COLUMN [tenant_id];