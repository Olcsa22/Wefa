ALTER TABLE quick_contact ADD COLUMN meta_field_name1 VARCHAR(50);
ALTER TABLE quick_contact ADD COLUMN meta_field_value1 VARCHAR(100);

ALTER TABLE quick_contact ADD COLUMN meta_field_name2 VARCHAR(50);
ALTER TABLE quick_contact ADD COLUMN meta_field_value2 VARCHAR(100);

ALTER TABLE quick_contact ADD COLUMN meta_field_name3 VARCHAR(50);
ALTER TABLE quick_contact ADD COLUMN meta_field_value3 VARCHAR(100);